--[[
    Hi, this script does nothing.
    The reason why the "IconModule" is a script is because it's easier to keep the custom properties consistent for scripts.
]]