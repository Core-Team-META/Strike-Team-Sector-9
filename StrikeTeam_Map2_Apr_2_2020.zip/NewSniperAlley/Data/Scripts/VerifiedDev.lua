local VerifiedPlayers = {

    "d6d9d578840a44c79a3f05c15de23bf8", -- Aggripina
    "eea739085f20445392c0ab999ab87bb6", -- Aj
    "0ea6612ceab7456a8a3a963a94808295", -- Blaking
    "557d4f1ae17646579646dfd20dcb7b66", -- AwkwardGameDev
    "d5daea732ee3422fbe85aecb900e73ec", -- Coderz
    "1f0588bf88d14c258d7384902f71f132", -- Daddio
    "1f3edd620c904e30a4e0223dd64bcc2a", -- Keppu
    "1f67a03d5a8f478b993aad1c79b45640", -- Rolok
    "385b45d7abdb499f8664c6cb01df521b", -- estlogic
    "9cc8d222e6d14da68dc2ba0a9a4f0439", -- Melamoryxq
    "d1073dbcc404405cbef8ce728e53d380", -- Morticai
    "94d3fd50c4824f019421895ec8dbf099", -- Mucusinator
    "91166471c6ea4d17be6772da4973e6b7", -- mjcortes782
    "e730c40ae54d4c588658667927acc6d8", -- WitcherSilver
    "400d8e7acb154e5bb64368411824b61d", -- Bigglebuns
    "c14f61b74826471f974f06ff7e42d97b", -- Basilisk
    "901b7628983c4c8db4282f24afeda57a", -- Buckmonsters

}

return VerifiedPlayers