function Tick(dt)
    _G["DeltaTime"] = dt
end