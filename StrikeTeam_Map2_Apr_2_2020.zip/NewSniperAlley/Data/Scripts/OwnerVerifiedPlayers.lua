local VerifiedPlayers = {
    "400d8e7acb154e5bb64368411824b61d", -- Bigglebuns
    "c14f61b74826471f974f06ff7e42d97b", -- Basilisk
    "901b7628983c4c8db4282f24afeda57a", -- Buckmonster
}

return VerifiedPlayers