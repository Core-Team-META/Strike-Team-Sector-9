_G["LOBBYLINK"] = script:GetCustomProperty("LobbyLink")
