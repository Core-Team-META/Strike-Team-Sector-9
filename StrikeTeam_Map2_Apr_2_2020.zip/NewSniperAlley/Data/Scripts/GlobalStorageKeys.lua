local WeaponStorage = script:GetCustomProperty("WeaponStorage")

_G["StorageKeys"] = {}
_G["StorageKeys"]["Weapons"] = WeaponStorage