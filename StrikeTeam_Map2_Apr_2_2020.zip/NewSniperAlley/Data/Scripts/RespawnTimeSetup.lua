local RESPAWNTIME = script:GetCustomProperty("RESPAWNTIME")
local MINRESPAWNTIME = script:GetCustomProperty("MINRESPAWNTIME")

_G["Respawnsettings.RESPAWNTIME"] = RESPAWNTIME
_G["Respawnsettings.MINRESPAWNTIME"] = MINRESPAWNTIME
