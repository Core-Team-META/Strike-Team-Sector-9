
function Tick(dt)
    print(Task.Wait(.08))
end