local Head = script:GetCustomProperty("Head"):WaitForObject()
local Default = script:GetCustomProperty("Default"):WaitForObject()

_G["DefaultPlayerSetting"] = Default
_G["HeadPlayerSetting"] = Head