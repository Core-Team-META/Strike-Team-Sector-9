Task.Wait()
Events.Broadcast("Minimap.AddItem",script.parent,"CE4C796C320F612C:TestMiniMapImage",nil)

