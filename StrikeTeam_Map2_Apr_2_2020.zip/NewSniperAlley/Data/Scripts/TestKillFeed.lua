

local WEAPONS = script:GetChildren()
local weaponTable = {}

local counter = 1
for _, value in pairs(WEAPONS) do
    weaponTable[counter] = value
    counter = counter + 1
end

function GetShortId(object)
	return string.sub(object.id, 1, string.find(object.id, ":") - 1)
end

function TablePrint(tbl, indent)
    local formatting, lua_type
    if tbl == nil then
        print("Table was nil")
        return
    end
    if type(tbl) ~= "table" then
        print("Table is not a table, it is a " .. type(tbl))
        return
    end
    if next(tbl) == nil then
        print("Table is empty")
        return
    end
    if not indent then
        indent = 0
    end
    -- type(v) returns nil, number, string, function, CFunction, userdata, and table.
    -- type(v) returns string, number, function, boolean, table or nil
    for k, v in pairs(tbl) do
        formatting = string.rep("  ", indent) .. k .. ": "
        lua_type = type(v)
        if lua_type == "table" then
            print(formatting)
            TablePrint(v, indent + 1)
        elseif lua_type == "boolean" then
            print(formatting .. tostring(v))
        elseif lua_type == "function" then
            print(formatting .. "function")
        elseif lua_type == "userdata" then
            print(formatting .. "userdata")
        else
            print(formatting .. v)
        end
    end
end

function OnBindingPressed(whichPlayer, binding)
	if (binding == "ability_extra_9") then
        local equipment = weaponTable[math.random(1, #weaponTable)]

        whichPlayer.hitPoints = math.random(1, 100)
        whichPlayer.name = "Buckmonster"
		Events.BroadcastToAllPlayers("PlayerKilled", whichPlayer, whichPlayer, GetShortId(equipment), math.random(0, 3))
	end
end

function OnBindingReleased(whichPlayer, binding)
	if (binding == "ability_extra_9") then

	end
end

function OnPlayerJoined(player)
	-- hook up binding in player joined event here, move to more appropriate place if needed
	player.bindingPressedEvent:Connect(OnBindingPressed)
	player.bindingReleasedEvent:Connect(OnBindingReleased)
end

-- on player joined/left functions need to be defined before calling event:Connect()
Game.playerJoinedEvent:Connect(OnPlayerJoined)