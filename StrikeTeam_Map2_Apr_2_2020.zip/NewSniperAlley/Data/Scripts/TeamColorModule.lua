local API = {
    script:GetCustomProperty("Team1"),
    script:GetCustomProperty("Team2"),
    script:GetCustomProperty("Team3"),
    script:GetCustomProperty("Team4"),
    nil
}

return API