
--[[

Primary | Assault Rifle
____________________________________
HK_LE -- level: 0 rarity: Rare | MRCi 88:LeatherBound
HK_SN -- level: 0 rarity: Common | MRCi 88:Snow
HK_LA -- level: 0 rarity: Rare | MRCi 88:Laser
HK_CA -- level: 0 rarity: Common | MRCi 88:Camo
HK_FR -- level: 0 rarity: Common | MRCi 88:Fren
HK_TY -- level: 0 rarity: Rare | MRCi 88:Toy
HK_LO -- level: 0 rarity: Legendary | MRCi 88:Legion of Light
HK_DD -- level: 0 rarity: Legendary | MRCi 88:Dark Devout
HK_GD -- level: 0 rarity: Legendary | MRCi 88:Gold
HK_SP -- level: 0 rarity: Epic | MRCi 88:Steam Punk
HK_JK -- level: 0 rarity: Epic | MRCi 88:Energy Buster
HK_CP -- level: 0 rarity: Legendary | MRCi 88:Cyber Punk
HK_WW -- level: 0 rarity: Rare | MRCi 88:WW2
HK_DE -- level: 0 rarity: Epic | MRCi 88:Demon Hunter
Primary | Sub Machine Gun
____________________________________
SP_SN -- level: 0 rarity: Common | EST CMB0:Snow
SP_LA -- level: 0 rarity: Rare | EST CMB0:Laser
SP_CA -- level: 0 rarity: Common | EST CMB0:Camo
SP_TY -- level: 0 rarity: Rare | EST CMB0:Toy
SP_FR -- level: 0 rarity: Common | EST CMB0:Fren
SP_LO -- level: 0 rarity: Legendary | EST CMB0:Legion of Light
SP_DD -- level: 0 rarity: Legendary | EST CMB0:Dark Devout
SP_GD -- level: 0 rarity: Legendary | EST CMB0:Gold
SP_SP -- level: 0 rarity: Epic | EST CMB0:Steam Punk
SP_CP -- level: 0 rarity: Legendary | EST CMB0:Cyber Punk
SP_WW -- level: 0 rarity: Rare | EST CMB0:WW2
SP_JK -- level: 0 rarity: Epic | EST CMB0:Junker
SP_DE -- level: 0 rarity: Epic | EST CMB0:Demon Hunter
Primary | Shotgun
____________________________________
LM_SN -- level: 0 rarity: Common | BCK 3000:Snow
LM_LA -- level: 0 rarity: Rare | BCK 3000:Laser
LM_CA -- level: 0 rarity: Common | BCK 3000:Camo
LM_FR -- level: 0 rarity: Common | BCK 3000:Fren
LM_LO -- level: 0 rarity: Legendary | BCK 3000:Legion of Light
LM_DD -- level: 0 rarity: Legendary | BCK 3000:Dark Devout
LM_GD -- level: 0 rarity: Legendary | BCK 3000:Gold
LM_SP -- level: 0 rarity: Epic | BCK 3000:Steam Punk
LM_TY -- level: 0 rarity: Rare | BCK 3000:Toy
LM_JK -- level: 0 rarity: Epic | BCK 3000:Junker
LM_CP -- level: 0 rarity: Legendary | BCK 3000:Cyber Punk
LM_WW -- level: 0 rarity: Rare | BCK 3000:WW2
LM_DE -- level: 0 rarity: Epic | BCK 3000:Demon Hunter
Primary | Marksman Rifle
____________________________________
SV_SN -- level: 0 rarity: Common | BLK NG7:Snow
SV_LA -- level: 0 rarity: Rare | BLK NG7:Laser
SV_CA -- level: 0 rarity: Common | BLK NG7:Camo
SV_FR -- level: 0 rarity: Common | BLK NG7:Fren
SV_LO -- level: 0 rarity: Legendary | BLK NG7:Legion of Light
SV_DD -- level: 0 rarity: Legendary | BLK NG7:Dark Devout
SV_GD -- level: 0 rarity: Legendary | BLK NG7:Gold
SV_SP -- level: 0 rarity: Epic | BLK NG7:Steam Punk
SV_TY -- level: 0 rarity: Rare | BLK NG7:Toy
SV_JK -- level: 0 rarity: Epic | BLK NG7:Junker
SV_CP -- level: 0 rarity: Legendary | BLK NG7:Cyber Punk
SV_WW -- level: 0 rarity: Rare | BLK NG7:WW2
SV_DE -- level: 0 rarity: Epic | BLK NG7:Demon Hunter
Primary | Sniper Rifle
____________________________________
SR_SN -- level: 0 rarity: Common | T055 ACn:Snow
SR_LA -- level: 0 rarity: Rare | T055 ACn:Laser
SR_CA -- level: 0 rarity: Common | T055 ACn:Camo
SR_FR -- level: 0 rarity: Common | T055 ACn:Fren
SR_LO -- level: 0 rarity: Legendary | T055 ACn:Legion of Light
SR_DD -- level: 0 rarity: Legendary | T055 ACn:Dark Devout
SR_GD -- level: 0 rarity: Legendary | T055 ACn:Gold
SR_SP -- level: 0 rarity: Epic | T055 ACn:Steam Punk
SR_TY -- level: 0 rarity: Rare | T055 ACn:Toy
SR_JK -- level: 0 rarity: Epic | T055 ACn:Junker
SR_CP -- level: 0 rarity: Legendary | T055 ACn:Cyber Punk
SR_WW -- level: 0 rarity: Rare | T055 ACn:WW2
SR_DE -- level: 0 rarity: Epic | T055 ACn:Demon Hunter
Primary | Light Machine Gun
____________________________________
NE_SN -- level: 0 rarity: Common | AWK R0K:Snow
NE_LA -- level: 0 rarity: Rare | AWK R0K:Laser
NE_CA -- level: 0 rarity: Common | AWK R0K:Camo
NE_FR -- level: 0 rarity: Common | AWK R0K:Fren
NE_LO -- level: 0 rarity: Legendary | AWK R0K:Legion of Light
NE_DD -- level: 0 rarity: Legendary | AWK R0K:Dark Devout
NE_GD -- level: 0 rarity: Legendary | AWK R0K:Gold
NE_SP -- level: 0 rarity: Epic | AWK R0K:Steam Punk
NE_TY -- level: 0 rarity: Rare | AWK R0K:Toy
NE_JK -- level: 0 rarity: Epic | AWK R0K:Junker
NE_CP -- level: 0 rarity: Legendary | AWK R0K:Cyber Punk
NE_WW -- level: 0 rarity: Rare | AWK R0K:WW2
NE_DE -- level: 0 rarity: Epic | AWK R0K:Demon Hunter
Secondary | Pistol
____________________________________
S4_SN -- level: 0 rarity: Common | KZ99:Snow
S4_LA -- level: 0 rarity: Rare | KZ99:Laser
S4_CA -- level: 0 rarity: Common | KZ99:Camo
S4_FR -- level: 0 rarity: Common | KZ99:Fren
S4_LO -- level: 0 rarity: Legendary | KZ99:Legion of Light
S4_DD -- level: 0 rarity: Legendary | KZ99:Dark Devout
S4_GD -- level: 0 rarity: Legendary | KZ99:Gold
S4_SP -- level: 0 rarity: Epic | KZ99:Steam Punk
S4_TY -- level: 0 rarity: Rare | KZ99:Toy
S4_AQ -- level: 0 rarity: Rare | KZ99:Aquatic
S4_LE -- level: 0 rarity: Rare | KZ99:LeatherBound
S4_WW -- level: 0 rarity: Rare | KZ99:WW2
S4_JK -- level: 0 rarity: Epic | KZ99:Junker
S4_S2 -- level: 0 rarity: Epic | KZ99:Steam Shock
S4_CP -- level: 0 rarity: Legendary | KZ99:Cyber Punk
S4_DE -- level: 0 rarity: Epic | KZ99:Demon Hunter
EZ_SN -- level: 0 rarity: Common | MJC 782:Snow
EZ_LA -- level: 0 rarity: Rare | MJC 782:Laser
EZ_CA -- level: 0 rarity: Common | MJC 782:Camo
EZ_FR -- level: 0 rarity: Common | MJC 782:Fren
EZ_LO -- level: 0 rarity: Legendary | MJC 782:Legion of Light
EZ_DD -- level: 0 rarity: Legendary | MJC 782:Dark Devout
EZ_SP -- level: 0 rarity: Epic | MJC 782:Steam Punk
EZ_GD -- level: 0 rarity: Legendary | MJC 782:Gold
EZ_TY -- level: 0 rarity: Rare | MJC 782:Toy
EZ_WW -- level: 0 rarity: Rare | MJC 782:WW2
EZ_JK -- level: 0 rarity: Epic | MJC 782:Junker
EZ_CP -- level: 0 rarity: Legendary | MJC 782:Cyber Punk
EZ_DE -- level: 0 rarity: Epic | MJC 782:Demon Hunter


Melee | Pan
____________________________________
PN_BE -- level: 0 rarity: Epic | Frying Pan:Bacon'n'Egg
PN_PA -- level: 0 rarity: Legendary | Frying Pan:Paddle 
PN_CU -- level: 0 rarity: Common | Frying Pan:Copper 
PN_CI -- level: 0 rarity: Rare | Frying Pan:CastIron
PN_TY -- level: 0 rarity: Epic | Frying Pan:Toy
PN_CP -- level: 0 rarity: Legendary | Frying Pan:Cyber Punk
PN_CA -- level: 0 rarity: Rare | Frying Pan:Cathy


Melee | Knife
____________________________________
LI_RZ -- level: 0 rarity: Common | LilRipper:Razer
LI_HE -- level: 0 rarity: Common | LilRipper:HotEdge
LI_TR -- level: 0 rarity: Common | LilRipper:Transformer
LI_RP -- level: 0 rarity: Common | LilRipper:Razer Purple
LI_RW -- level: 0 rarity: Common | LilRipper:Razer White
LI_RG -- level: 0 rarity: Common | LilRipper:Razer Green
LI_GI -- level: 0 rarity: Common | LilRipper:Genji
LI_BC -- level: 0 rarity: Common | LilRipper:Blues Clues
LI_LL -- level: 0 rarity: Common | LilRipper:Lemon Lime
LI_AT -- level: 0 rarity: Common | LilRipper:Az-tech
LI_BB -- level: 0 rarity: Common | LilRipper:BumbleBee
LI_BF -- level: 0 rarity: Rare | LilRipper:Blue Fibre
LI_LE -- level: 0 rarity: Rare | LilRipper:Laser Edge
LI_SR -- level: 0 rarity: Rare | LilRipper:Salamander
LI_PA -- level: 0 rarity: Common | LilRipper:Pavlova
LI_SM -- level: 0 rarity: Common | LilRipper:Snow Recon
LI_NE -- level: 0 rarity: Common | LilRipper:Never Eat
LI_TF -- level: 0 rarity: Common | LilRipper:Tundra Flame
LI_VE -- level: 0 rarity: Common | LilRipper:Vile
LI_SY -- level: 0 rarity: Common | LilRipper:Smokey
LI_IC -- level: 0 rarity: Common | LilRipper:Ice cold
LI_PC -- level: 0 rarity: Common | LilRipper:Purple Cold
LI_YL -- level: 0 rarity: Common | LilRipper:Yellow Lantern
LI_NN -- level: 0 rarity: Common | LilRipper:Neon
LI_NP -- level: 0 rarity: Legendary | LilRipper:Golden
LI_HB -- level: 0 rarity: Rare | LilRipper:Hot Beam
LI_CB -- level: 0 rarity: Rare | LilRipper:Cold Beam
LI_SC -- level: 0 rarity: Common | LilRipper:Snow Camo
LI_HH -- level: 0 rarity: Common | LilRipper:HoloBlade
LI_SP -- level: 0 rarity: Common | LilRipper:Spice
LI_SG -- level: 0 rarity: Common | LilRipper:Stained Glass
LI_DO -- level: 0 rarity: Rare | LilRipper:Half-life
LI_WB -- level: 0 rarity: Common | LilRipper:Ghost
LI_LB -- level: 0 rarity: Rare | LilRipper:Lava Edge
LI_AB -- level: 0 rarity: Common | LilRipper:Autobot
LI_RL -- level: 0 rarity: Common | LilRipper:Rum and Lime
LI_HG -- level: 0 rarity: Common | LilRipper:Hologram green
LI_SN -- level: 0 rarity: Common | LilRipper:SnowCone
LI_AY -- level: 0 rarity: Common | LilRipper:Amethyst
LI_RB -- level: 0 rarity: Legendary | LilRipper:Rainbow Dragon
LI_TY -- level: 0 rarity: Rare | LilRipper:Toy
LI_S2 -- level: 0 rarity: Epic | LilRipper:Steam Shock
LI_JK -- level: 0 rarity: Epic | LilRipper:Makeshift Machete
LI_SK -- level: 0 rarity: Epic | LilRipper:Obsidian Shank
LI_AQ -- level: 0 rarity: Rare | LilRipper:Aquatic
LI_CP -- level: 0 rarity: Legendary | LilRipper:Cyber Punk
LI_DE -- level: 0 rarity: Epic | LilRipper:Demon Hunter


Melee | Bat
____________________________________
BA_CP -- level: 0 rarity: Legendary | Bat:Cyber Punk
BA_OR -- level: 0 rarity: Common | Bat:Ol' Reliable
BA_GD -- level: 0 rarity: Legendary | Bat:Golden
BA_WD -- level: 0 rarity: Common | Bat:Wood
BA_HE -- level: 0 rarity: Common | Bat:<3
BA_FM -- level: 0 rarity: Common | Bat:Foam
BA_TY -- level: 0 rarity: Rare | Bat:Toy
BA_SP -- level: 0 rarity: Epic | Bat:Spiked
BA_S2 -- level: 0 rarity: Epic | Bat:Steam Shock
BA_SC -- level: 0 rarity: Epic | Bat:The Skullcrusher
BA_PD -- level: 0 rarity: Rare | Bat:Pipe
BA_WI -- level: 0 rarity: Legendary | Bat:Biggle Bat
BA_BD -- level: 0 rarity: Rare | Bat:Dirty Bat


Equipment | Lethal
____________________________________


Equipment | Utility
____________________________________


Perks | Passives
____________________________________


Special | Rocket Launcher
____________________________________
MC_SN -- level: 0 rarity: Common | ME7A:Snow
MC_LA -- level: 0 rarity: Rare | ME7A:Laser
MC_CA -- level: 0 rarity: Common | ME7A:Camo
MC_FR -- level: 0 rarity: Common | ME7A:Fren
MC_LO -- level: 0 rarity: Legendary | ME7A:Legion of Light
MC_DD -- level: 0 rarity: Legendary | ME7A:Dark Devout
MC_GD -- level: 0 rarity: Legendary | ME7A:Gold
MC_BQ -- level: 15 rarity: Legendary | ME7A:BBQuzooka
MC_SP -- level: 0 rarity: Epic | ME7A:Steam Punk
MC_TY -- level: 0 rarity: Rare | ME7A:Toy
MC_JK -- level: 0 rarity: Epic | ME7A:The Iron Manticore 
MC_CP -- level: 0 rarity: Legendary | ME7A:Cyber Punk
Special | Hatchet
____________________________________
HA_IC -- level: 0 rarity: Common | Hatchet:Ice
HA_PU -- level: 0 rarity: Common | Hatchet:Pulse
HA_LA -- level: 0 rarity: Common | Hatchet:Lava
HA_GH -- level: 0 rarity: Common | Hatchet:Ghost
HA_FM -- level: 0 rarity: Common | Hatchet:Fireman
HA_CH -- level: 0 rarity: Common | Hatchet:Cherry
HA_BA -- level: 0 rarity: Common | Hatchet:Balance
HA_SC -- level: 0 rarity: Common | Hatchet:Sketch
Special | Mace
____________________________________
MA_LA -- level: 0 rarity: Common | Mace:Lava
MA_GI -- level: 0 rarity: Common | Mace:Genji
MA_HF -- level: 0 rarity: Common | Mace:HeartFire
MA_MO -- level: 0 rarity: Common | Mace:Magic Obsidian
MA_RS -- level: 0 rarity: Common | Mace:Rose
MA_CL -- level: 0 rarity: Common | Mace:Cool
MA_GD -- level: 0 rarity: Legendary | Mace:Golden


Special | Pickaxe
____________________________________
PI_GD -- level: 0 rarity: Legendary | Pickaxe:Golden
PI_LA -- level: 0 rarity: Common | Pickaxe:Lava
PI_PU -- level: 0 rarity: Common | Pickaxe:Pure
PI_HR -- level: 0 rarity: Common | Pickaxe:Hotrod
PI_EM -- level: 0 rarity: Common | Pickaxe:Emissive


Special | IcePick
____________________________________
TP_CH -- level: 0 rarity: Legendary | IcePick:Holiday


Special | Junk
____________________________________


Special | Needed



--]]