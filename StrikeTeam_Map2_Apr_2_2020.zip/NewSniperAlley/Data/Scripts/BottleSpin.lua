
local x = math.random() * 100 - 50
script:RotateContinuous(Rotation.New(x, -90, 0), 6, true)