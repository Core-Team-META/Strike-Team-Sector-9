_G["ABGS"] = require(script:GetCustomProperty("AGBS"))
